
package controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;


public class AdminHomeScreenFxmlController implements Initializable { 

    @FXML
    private TabPane adminTabPane;
    @FXML
    private Tab addQuizTab;
    @FXML
    private Tab addStudentTab;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
