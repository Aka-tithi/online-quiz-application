/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cnstant;

/**
 *
 * @author Sowrav Dey
 */

public class DatabaseConstants {
    public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver"; // or "org.sqlite.JDBC"
    public static final String CONNECTION_URL = "jdbc:mysql://localhost:3306/online_quiz?zeroDateTimeBehavior=CONVERT_TO_NULL";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "123456";
}
