
package cnstant;

public class AdminEmailPassword {
    public static String email = "admin@gmail.com";
    public static String password = "123456";
}
